1. Backward Euler and Crank-Nicholson in file "backward_CrankNich_heat.m".
	
2. Periodic problem in file "CN_PeriodicRef.m"
	It is not important to run code for reference solution. Values have
	already been stored in "RefPeriodic.mat"

3. Fishers problem in file "fishersProb.m"